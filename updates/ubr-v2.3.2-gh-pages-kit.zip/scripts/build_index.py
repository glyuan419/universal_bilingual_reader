#!/usr/bin/env python3
"""Scan library/ for .zip packages, unpacked folders (doc.json / paper.json), and legacy .html files,
and generate a rich catalog.json index for Universal Bilingual Reader."""

import json
import os
import re
import zipfile
from datetime import datetime, timezone

LIBRARY_DIR = "library"
OUT_FILE = "catalog.json"


def format_authors(raw_authors):
    if isinstance(raw_authors, list):
        names = []
        for a in raw_authors:
            if isinstance(a, str) and a.strip():
                names.append(a.strip())
            elif isinstance(a, dict) and str(a.get("name", "")).strip():
                names.append(str(a["name"]).strip())
        return ", ".join(names)
    return str(raw_authors or "").strip()


def normalize_tag(tag):
    s = str(tag or "").strip()
    if not s:
        return ""
    m = re.search(r"\(([a-z][a-z-]*(?:\.[A-Z-]+)?)\)\s*$", s)
    return m.group(1) if m else s


def parse_tags(subjects):
    if not subjects:
        return []
    parts = [normalize_tag(p) for p in re.split(r"[,;，；、]+", str(subjects))]
    parts = [p for p in parts if p]
    return list(dict.fromkeys(parts))[:4]


def safe_truncate_math(text, max_len=360):
    clean = re.sub(r"<[^>]+>", "", str(text or ""))
    clean = re.sub(r"\s+", " ", clean).strip()
    if len(clean) <= max_len:
        return clean
    cut = max_len
    in_math = False
    last_safe = 0
    limit = min(len(clean), max_len + 40)
    for i in range(limit):
        if clean[i] == "$" and (i == 0 or clean[i - 1] != "\\"):
            in_math = not in_math
            if not in_math and i < max_len + 36:
                last_safe = i + 1
        elif not in_math and i <= max_len:
            last_safe = i + 1
        if i >= max_len and not in_math:
            cut = i + 1
            break
    if in_math and last_safe > 40:
        cut = last_safe
    return clean[:cut].strip()


def extract_summary(paper_obj):
    blocks = paper_obj.get("blocks") or []
    cand = None
    for b in blocks:
        if isinstance(b, dict) and b.get("type") == "abstract":
            cand = b
            break
    if cand is None:
        for b in blocks:
            if isinstance(b, dict) and b.get("type") == "paragraph" and re.match(r"^sec-abstract$", str(b.get("sectionId") or ""), re.I):
                cand = b
                break
    if cand is None:
        for b in blocks:
            if isinstance(b, dict) and b.get("type") == "paragraph" and (b.get("zh") or b.get("en")):
                cand = b
                break
    if not cand:
        return ""
    return safe_truncate_math(cand.get("zh") or cand.get("en") or "", 360)


def build_entry(file_rel, kind, paper_obj):
    meta = (paper_obj.get("meta") or {}) if isinstance(paper_obj, dict) else {}
    return {
        "file": file_rel,
        "kind": kind,
        "docId": str(meta.get("docId") or "").strip(),
        "sourceLabel": str(meta.get("sourceLabel") or "").strip(),
        "titleEn": str(meta.get("titleEn") or "").strip(),
        "titleZh": str(meta.get("titleZh") or "").strip(),
        "authors": format_authors(meta.get("authors")),
        "venue": str(meta.get("venue") or "").strip(),
        "date": str(meta.get("date") or meta.get("submitted") or "").strip(),
        "tags": parse_tags(meta.get("subjects")),
        "summary": extract_summary(paper_obj),
    }


def read_zip_paper(zip_path):
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = [n for n in zf.namelist() if not n.endswith("/") and not n.startswith("__MACOSX/")]
        json_names = [n for n in names if n.lower().endswith(".json") and not n.lower().endswith("annotations.json")]
        if not json_names:
            return {}
        json_names.sort(key=lambda n: (0 if n.lower().endswith("doc.json") else (1 if n.lower().endswith("paper.json") else 2), len(n)))
        return json.loads(zf.read(json_names[0]).decode("utf-8"))


def read_html_paper(html_path):
    with open(html_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    m = re.search(r'<script[^>]*\bid=["\']paper-data["\'][^>]*>([\s\S]*?)</script>', text, re.I)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    t = re.search(r"<title[^>]*>([\s\S]*?)</title>", text, re.I)
    return {"meta": {"titleEn": re.sub(r"\s+", " ", t.group(1)).strip()}} if t else {}


def main():
    items = []
    if os.path.isdir(LIBRARY_DIR):
        for name in sorted(os.listdir(LIBRARY_DIR)):
            if name.startswith(".") or name.startswith("__"):
                continue
            full = os.path.join(LIBRARY_DIR, name)
            try:
                if os.path.isfile(full) and name.lower().endswith(".zip"):
                    items.append(build_entry(name, "zip", read_zip_paper(full)))
                elif os.path.isdir(full):
                    json_cand = os.path.join(full, "doc.json")
                    if not os.path.isfile(json_cand):
                        json_cand = os.path.join(full, "paper.json")  # [compat <= 1.1.0]
                    if os.path.isfile(json_cand):
                        with open(json_cand, "r", encoding="utf-8") as f:
                            items.append(build_entry(name + "/", "folder", json.load(f)))
                elif os.path.isfile(full) and name.lower().endswith((".html", ".htm")):
                    items.append(build_entry(name, "html", read_html_paper(full)))
            except Exception as exc:
                print(f"[warn] skipped {name}: {exc}")

    items.sort(key=lambda x: (x.get("date") or "", x.get("titleEn") or x.get("file") or ""), reverse=True)

    payload = {
        "dir": LIBRARY_DIR,
        "generatedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "items": items,
    }
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"Generated {OUT_FILE} with {len(items)} item(s).")


if __name__ == "__main__":
    main()
